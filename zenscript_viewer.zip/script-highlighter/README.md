# Notepad++ ZenScript Highlighter
The repository for my ZenScript Highlighter add-on for Notepad++

You can download it, view the "code", contribute, [report issues](https://github.com/vizthex123/script-highlighter/issues), etc.

If you've got suggestions for mods to add, just [make a PR](https://github.com/vizthex123/script-highlighter/pulls) and change the file to support the mod(s), then be sure to label it as such.

Alternatively, you can [make a suggestion](https://github.com/vizthex123/script-highlighter/issues) and simply include links to the mod page and CraftTweaker documentation for it/them.

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/O5O1ADTG2)
