To install this extension, open Notepad++ and go to Language -> User Defined Language -> Define Your Language... -> Import and select highlighter_new.xml

It should import as ZenScript 1.14+, and must be manually selected from the User Defined Language drop-down when a ZenScript file is open.

I don't think it's possible to have it auto-select when opening a .zs file, but if you know how let me know.